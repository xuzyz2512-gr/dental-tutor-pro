const test = require('node:test'), assert = require('node:assert');
const { createServer } = require('../server');
const start = async o => { const s = createServer(o); await new Promise(r => s.listen(0, r)); return [s, `http://127.0.0.1:${s.address().port}`]; };
const post = (u, b) => fetch(u + '/api/tutor', { method: 'POST', body: JSON.stringify(b) });
const ok = { messages: [{ role: 'user', text: 'What is enamel?' }] };
const gem = (status, body) => async () => ({ status, ok: status < 400, json: async () => body });

test('health and data', async () => {
  const [s, u] = await start({ apiKey: '' });
  assert.equal((await fetch(u + '/health')).status, 200);
  const d = await (await fetch(u + '/api/data')).json();
  assert.ok(d.questions.length && d.cards.length);
  assert.equal((await fetch(u + '/%2e%2e/server.js')).status, 404);
  s.closeAllConnections(); s.close();
});
test('tutor: 503 without key', async () => { const [s, u] = await start({ apiKey: '' }); assert.equal((await post(u, ok)).status, 503); s.closeAllConnections(); s.close(); });
test('tutor: 400 on bad input', async () => {
  const [s, u] = await start({ apiKey: 'k' });
  for (const b of [{}, { messages: [] }, { messages: [{ role: 'x', text: 'a' }] }, { messages: [{ role: 'user', text: 'a'.repeat(2001) }] }]) assert.equal((await post(u, b)).status, 400);
  s.closeAllConnections(); s.close();
});
test('tutor: mocked Gemini success', async () => {
  const [s, u] = await start({ apiKey: 'k', fetchImpl: gem(200, { candidates: [{ content: { parts: [{ text: 'Enamel is...' }] } }] }) });
  const r = await post(u, ok); assert.equal(r.status, 200); assert.equal((await r.json()).reply, 'Enamel is...'); s.closeAllConnections(); s.close();
});
test('tutor: upstream 429 and 500', async () => {
  let [s, u] = await start({ apiKey: 'k', fetchImpl: gem(429, {}) }); assert.equal((await post(u, ok)).status, 503); s.closeAllConnections(); s.close();
  [s, u] = await start({ apiKey: 'k', fetchImpl: gem(500, {}) }); assert.equal((await post(u, ok)).status, 502); s.closeAllConnections(); s.close();
});
test('tutor: rate limit', async () => {
  const [s, u] = await start({ apiKey: 'k', limit: 2, fetchImpl: gem(200, { candidates: [{ content: { parts: [{ text: 'x' }] } }] }) });
  const codes = []; for (let i = 0; i < 3; i++) codes.push((await post(u, ok)).status);
  assert.deepEqual(codes, [200, 200, 429]); s.closeAllConnections(); s.close();
});
