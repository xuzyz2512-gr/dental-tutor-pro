'use strict';
const http = require('http'), fs = require('fs'), path = require('path');
const PUB = path.join(__dirname, 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json' };
const SYSTEM = 'You are Dental Tutor Pro, an educational assistant for dental students. Explain accurately, in a structured way, at the requested level. This is for education only, not diagnosis or treatment of a real patient; say so when asked about a specific case. If unsure, say so instead of guessing.';
const DATA = fs.readFileSync(path.join(__dirname, 'data', 'content.json'), 'utf8');

function createServer({ fetchImpl = fetch, apiKey = process.env.GEMINI_API_KEY, model = process.env.GEMINI_MODEL || 'gemini-2.5-flash', limit = 20 } = {}) {
  const hits = new Map();
  const limited = ip => { const now = Date.now(), a = (hits.get(ip) || []).filter(t => now - t < 60000); a.push(now); hits.set(ip, a); return a.length > limit; };
  const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(obj)); };
  const readBody = req => new Promise((ok, no) => { let s = ''; req.on('data', d => { s += d; if (s.length > 20000) { no(new Error('too large')); req.destroy(); } }); req.on('end', () => ok(s)); req.on('error', no); });

  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://x');
      if (url.pathname === '/health') return send(res, 200, { ok: true });
      if (url.pathname === '/api/data') { res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(DATA); }
      if (url.pathname === '/api/tutor' && req.method === 'POST') {
        if (!apiKey) return send(res, 503, { error: 'Tutor is not configured. Set GEMINI_API_KEY on the server.' });
        const ip = (req.headers['x-forwarded-for'] || '').split(',').pop().trim() || req.socket.remoteAddress;
        if (limited(ip)) return send(res, 429, { error: 'Too many requests. Wait a minute and try again.' });
        let b; try { b = JSON.parse(await readBody(req)); } catch { return send(res, 400, { error: 'Invalid request body.' }); }
        const m = b && b.messages;
        if (!Array.isArray(m) || !m.length || m.length > 20 || m.some(x => !x || !['user', 'model'].includes(x.role) || typeof x.text !== 'string' || !x.text.trim() || x.text.length > 2000) || m[m.length - 1].role !== 'user')
          return send(res, 400, { error: 'Send 1 to 20 messages (max 2000 characters each), ending with a user message.' });
        const level = b.level === 'advanced' ? 'advanced academic' : 'simple, beginner-friendly';
        const r = await fetchImpl(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
          method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
          body: JSON.stringify({ systemInstruction: { parts: [{ text: `${SYSTEM} Level: ${level}.` }] }, contents: m.map(x => ({ role: x.role, parts: [{ text: x.text }] })) })
        });
        if (r.status === 429) return send(res, 503, { error: 'The AI service is busy. Try again shortly.' });
        if (!r.ok) return send(res, 502, { error: 'The AI service returned an error.' });
        const j = await r.json();
        const text = (j.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('');
        return text ? send(res, 200, { reply: text }) : send(res, 502, { error: 'The AI service returned no answer.' });
      }
      if (req.method === 'GET') {
        const f = path.join(PUB, url.pathname === '/' ? 'index.html' : path.normalize(decodeURIComponent(url.pathname)));
        if (f.startsWith(PUB + path.sep)) {
          return fs.readFile(f, (e, buf) => {
            if (e) return send(res, 404, { error: 'Not found.' });
            res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' }); res.end(buf);
          });
        }
      }
      send(res, 404, { error: 'Not found.' });
    } catch (e) { console.error('request failed:', e.message); send(res, 500, { error: 'Server error.' }); }
  });
}
module.exports = { createServer };
if (require.main === module) {
  const port = process.env.PORT || 3000;
  createServer().listen(port, '0.0.0.0', () => console.log(`Dental Tutor Pro on :${port}${process.env.GEMINI_API_KEY ? '' : ' (tutor disabled: GEMINI_API_KEY not set)'}`));
}
